﻿namespace MyTypes;

public enum BndType
{
    Govt,
    Muni,
    Corp
}