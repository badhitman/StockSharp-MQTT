﻿namespace MyTypes;

public class CashFlow : IComparable<CashFlow>
{
    public DateTime StDate;
    public DateTime EndDate;
    public decimal CouponRate;
    public decimal Coupon;
    public decimal Notional;

    public CashFlow(DateTime stdate, DateTime enddate, decimal coupon, decimal notional, decimal couprate)
    {
        StDate = stdate;
        EndDate = enddate;
        Coupon = coupon;
        Notional = notional;
        CouponRate = couprate;
    }

    public int CompareTo(CashFlow other)
    {
        return EndDate.CompareTo(other.EndDate);
    }
}