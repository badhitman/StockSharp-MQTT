﻿using System.Windows;
using System.Windows.Controls;
using Ecng.Serialization;
using StockSharp.Algo;
using StockSharp.BusinessEntities;
using StockSharp.Configuration;
using StockSharp.Messages;
using StockSharp.Logging;
using StockSharp.Xaml;
using System.IO;
using Ecng.Xaml;
using Ecng.Collections;
using MyTypes;
using Ecng.Common;
using Xceed.Wpf.Toolkit;
using DevExpress.Mvvm;
using Ecng.ComponentModel;
using Subscription = StockSharp.Algo.Subscription;
using System.ComponentModel;
using Telegram.Bot;
using Telegram.Bot.Types.Enums;

namespace RobotAprilCap;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly Connector connector = new();
    #region prop`s
    private const string _connectorFile = "ConnectorFile.json";

    private readonly LogManager _logmanager = new();
    private readonly StockSharp.Xaml.Monitor _monitor = new();

    private readonly string[] OfzCodes = {
                        "SU29009RMFS6","SU29010RMFS4",
                        "SU29014RMFS6","SU29007RMFS0",
                        "SU29008RMFS8","SU29013RMFS8","SU29015RMFS3",
                        "SU29017RMFS9","SU29018RMFS7","SU29019RMFS5","SU29020RMFS3",
                        "SU29021RMFS1","SU29022RMFS9","SU29023RMFS7",
                        "SU29024RMFS5","SU29025RMFS2",
                        "SU52002RMFS1","SU52003RMFS9","SU52004RMFS7","SU52005RMFS4",
                        "SU26241RMFS8","SU26242RMFS6",
                        "SU26219RMFS4", "SU26226RMFS9", "SU26207RMFS9", "SU26232RMFS7",
                        "SU26212RMFS9", "SU26236RMFS8","SU26235RMFS0",
                        "SU26218RMFS6", "SU26221RMFS0", "SU26228RMFS5",
                        "SU26224RMFS4", "SU26225RMFS1",
                        "SU26229RMFS3", "SU26230RMFS1","SU26233RMFS5","SU26234RMFS3",
                        "SU26237RMFS6", "SU26238RMFS4","SU26239RMFS2","SU26240RMFS0",
                        "SU26243RMFS4", "SU26244RMFS2",

    };

    private readonly string[] OfzCodesNew =
    {
            "SU26245RMFS9", "SU26246RMFS7", "SU26247RMFS5", "SU26248RMFS3",
    };

    private readonly string[] OfzCodesIlliquid =
    {
            "SU46020RMFS2",
    };

    private readonly string ProgramPath = @"C:\AprilCapital\BondTrading\";

    private readonly string PortName = "S00+00002DFD";
    private readonly string ClCode = "SEACB_01/";

    private readonly List<Security> BondList = new();
    private readonly List<SBond> SBondList = new();
    private readonly List<SecurityPosition> SBondPositionsList = new();
    private readonly List<SecurityPosition> SBondSizePositionsList = new();
    private readonly List<SecurityPosition> SBondSmallPositionsList = new();
    private static readonly List<long?> list = new();
    private readonly List<long?> TradesList = list;

    private readonly FileSystemWatcher fileWatcher = new();

    private Curve OfzCurve;
    private decimal lowLimit = 0.19m;
    private decimal highLimit = 0.25m;
    private readonly decimal
        lowYieldLimit = 4m,
        highYieldLimit = 5m;

    private decimal quoteSmallStrategyBidVolume = 2000;
    private decimal quoteSmallStrategyOfferVolume = 2000;
    private decimal quoteStrategyVolume = 1000;
    private decimal skipVolume = 2500;
    private decimal quoteSizeStrategyVolume = 2000;

    private decimal bondPositionTraded;
    private decimal bondSizePositionTraded;
    private decimal bondSmallPositionTraded;
    private decimal bondOutOfRangePositionTraded;

    private Dictionary<string, Order> _ordersForQuoteBuyReregister;
    private Dictionary<string, Order> _ordersForQuoteSellReregister;

    private readonly Dictionary<Security, IOrderBookMessage> OderBookList = new();
    Portfolio MyPortf = new();
    private static readonly TelegramBotClient TelBot = new("256392515:AAGx4_PsSJO5xZMoCJPU0cZri1ASmB3SVzw");
    #endregion

    public MainWindow()
    {
        InitializeComponent();

        _logmanager.Listeners.Add(new GuiLogListener(_monitor));
        _logmanager.Listeners.Add(new FileLogListener(@"C:\AprilCapital\BondTrading\lognew.txt"));

        if (File.Exists(_connectorFile))
        {
            connector.Load(_connectorFile.Deserialize<SettingsStorage>());
        }
    }

    private void SendRequest(string secCode, decimal price, decimal volume, Sides direction)
    {
        if (System.Windows.MessageBox.Show(
            "Do you really want to " + (direction == Sides.Buy ? "BUY" : "SELL") + " " + volume.ToString("#") +
            " " + secCode + " bonds @" + " " + price.ToString("#.##"), "Confirmation", MessageBoxButton.YesNo) ==
            MessageBoxResult.Yes)
        {
            Order _order = new()
            {
                Security = connector.Securities.FirstOrDefault(s => (s.Code == secCode) && (s.Board == ExchangeBoard.MicexTqob)),
                Portfolio = connector.Portfolios.FirstOrDefault(p => p.Name == PortName),
                Side = direction,
                Price = price,
                Volume = volume,
                Comment = "Manual",
                IsMarketMaker = OfzCodes.Contains(secCode),
                ClientCode = ClCode,
            };

            connector.RegisterOrder(_order);
        }
    }

    private void Connect_Click(object sender, RoutedEventArgs e)
    {
        SecurityLookupWindow wnd = new()
        {
            ShowAllOption = connector.Adapter.IsSupportSecuritiesLookupAll(),
            Criteria = new Security { Type = SecurityTypes.Stock, Code = "SU" }
        };

        if (!wnd.ShowModal(this))
            return;

        connector.LookupSecurities(wnd.CriteriaMessage);

        //SecurityEditor.SecurityProvider = QTrader;
        PortfolioEditor.Portfolios = new PortfolioDataSource(connector);

        //Подписаться на событие появления новых портфелей
        connector.PortfolioReceived += (Sub, portfolios) =>
        {
            if (portfolios.Name == PortName)
            {
                MyPortf = portfolios;
            }
        };

        connector.SecurityReceived += (Sub, security) =>
        {
            //TODO For securities
            if ((OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code) || OfzCodesIlliquid.Contains(security.Code)) && (security.Board == ExchangeBoard.MicexTqob))
            {
                BondList.Add(security);
            }

            this.GuiAsync(() => CbSecurities.ItemsSource = BondList);
        };

        connector.OrderBookReceived += TraderOnMarketDepthReceived;
        connector.LogLevel = LogLevels.Debug;
        _logmanager.Sources.Add(connector);

        connector.Connect();

        TelBot.OnMessage += BotOnMessageReceived;
        TelBot.SendMessage(81746878, "TelegramBot started!");
    }

    #region SeparateBondFunctions
    private void BuyBondClick(object sender, RoutedEventArgs e)
    {
        decimal price = 0m;
        decimal volume = 0m;
        Button btn;
        string bondName;

        btn = sender as Button;
        bondName = btn.Name;
        bondName = bondName[^5..];

        DecimalUpDown bndPrice = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bondName);
        if (bndPrice.Value.HasValue)
            price = (decimal)bndPrice.Value;

        LongUpDown bndVolume = (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Volume_" + bondName);
        if (bndVolume.Value.HasValue)
            volume = (decimal)bndVolume.Value;

        if (price * volume == 0)
            return;
        SendRequest(connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + bondName)) && (s.Board == ExchangeBoard.MicexTqob)).Code, price, volume, Sides.Buy);
    }

    private void SellBondClick(object sender, RoutedEventArgs e)
    {
        decimal price = 0m;
        decimal volume = 0m;
        Button btn;
        string bondName;

        btn = sender as Button;
        bondName = btn.Name;
        bondName = bondName[^5..];

        var bndPrice = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bondName);
        if (bndPrice.Value.HasValue)
            price = (decimal)bndPrice.Value;

        var bndVolume = (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Volume_" + bondName);
        if (bndVolume.Value.HasValue)
            volume = (decimal)bndVolume.Value;

        if (price * volume == 0)
            return;
        SendRequest(connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + bondName)) && (s.Board == ExchangeBoard.MicexTqob)).Code, price, volume, Sides.Sell);
    }

    private void BidBondClick(object sender, RoutedEventArgs e)
    {
        decimal price = 0m;
        decimal volume = 0m;
        Button btn;
        string bondName;

        btn = sender as Button;
        bondName = btn.Name;
        bondName = bondName[^5..];

        //  var mdepth = QTrader.RegisteredMarketDepths.FirstOrDefault(s => (s.Code.Contains("SU" + bondName)) && (s.Board == ExchangeBoard.MicexTqob));
        //  if (!mdepth.IsNull())
        //  {
        //      price = mdepth.BestAsk..Price;
        //      volume = mdepth.BestAsk.Volume;
        //  }
        if (price * volume == 0)
            return;

        if (volume > 30000)
        {
            volume = 30000;
        }


        SendRequest(connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + bondName)) && (s.Board == ExchangeBoard.MicexTqob)).Code, price, volume, Sides.Buy);
    }

    private void OfferBondClick(object sender, RoutedEventArgs e)
    {
        decimal price = 0m;
        decimal volume = 0m;
        Button btn;
        string bondName;

        btn = sender as Button;
        bondName = btn.Name;
        bondName = bondName[^5..];

        var mdepth = connector.RegisteredMarketDepths.FirstOrDefault(s => (s.Code.Contains("SU" + bondName)) && (s.Board == ExchangeBoard.MicexTqob));
        if (!mdepth.IsNull())
        {
            //       price = mdepth.BestBid.Price;
            //       volume = mdepth.BestBid.Volume;
        }
        if (price * volume == 0)
            return;

        if (volume > 30000)
        {
            volume = 30000;
        }

        SendRequest(connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + bondName)) && (s.Board == ExchangeBoard.MicexTqob)).Code, price, volume, Sides.Sell);
    }
    #endregion

    private void TraderOnMarketDepthReceived(Subscription subscription, IOrderBookMessage depth)
    {
        Security sec = connector.Securities.FirstOrDefault(s => s.ToSecurityId() == depth.SecurityId);

        if ((!BondList.IsNull()) && BondList.Contains(sec))
        {
            if (OderBookList.ContainsKey(sec))
                OderBookList[sec] = depth;
            else
                OderBookList.Add(sec, depth);
        }
    }

    private void TestFunc(object sender, RoutedEventArgs e)
    {
        connector.SubscribeMarketDepth(BondList[1]);
        Order order = new()
        {
            Security = BondList[1],
            Portfolio = MyPortf,
            Price = 81.6m,
            Volume = 1,
            Side = Sides.Buy,
            ClientCode = PortName
        };
        connector.RegisterOrder(order);
    }

    private void Setting_Click(object sender, RoutedEventArgs e)
    {
        if (connector.Configure(this))
        {
            connector.LookupMessagesOnConnect.Remove(MessageTypes.SecurityLookup);
            connector.Save().Serialize(_connectorFile);
        }
    }

    private void InitialLoadClick(object sender, RoutedEventArgs e)
    {
        SBond SBnd;
        DateTime curDate;
        decimal BndPrice;
        decimal bondDV;

        OfzCurve = new Curve(MyHelper.GetNextWorkingDay(DateTime.Today, 1, ProgramPath + "RedArrowData.db"));
        OfzCurve.GetCurveFromDb(ProgramPath + "RedArrowData.db", connector);

        if (OfzCurve.Length == 0)
            return;

        if (!BondList.Any())
            return;

        if (BondList.Count < OfzCodes.Length + OfzCodesNew.Length + OfzCodesIlliquid.Length)
            return;

        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26234RMFS3") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26234", "RU000A101QE0", new DateTime(2020, 7, 22), new DateTime(2025, 7, 16), 0.045m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26229RMFS3") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26229", "RU000A100EG3", new DateTime(2019, 5, 22), new DateTime(2025, 11, 12), 0.0715m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26219RMFS4") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26219", "RU000A0JWM07", new DateTime(2016, 3, 30), new DateTime(2026, 9, 16), 0.0775m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26226RMFS9") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26226", "RU000A0ZZYW2", new DateTime(2018, 10, 17), new DateTime(2026, 10, 7), 0.0795m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26207RMFS9") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26207", "RU000A0JS3W6", new DateTime(2012, 2, 22), new DateTime(2027, 2, 3), 0.0815m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26232RMFS7") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26232", "RU000A1014N4", new DateTime(2019, 10, 16), new DateTime(2027, 10, 6), 0.060m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26212RMFS9") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26212", "RU000A0JTK38", new DateTime(2013, 8, 7), new DateTime(2028, 1, 19), 0.0705m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26236RMFS8") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26236", "RU000A102BT8", new DateTime(2020, 11, 25), new DateTime(2028, 5, 17), 0.057m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26237RMFS6") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26237", "RU000A1038Z7", new DateTime(2021, 3, 24), new DateTime(2029, 3, 14), 0.067m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26242RMFS6") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26242", "RU000A105RV3", new DateTime(2022, 9, 7), new DateTime(2029, 8, 29), 0.09m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26224RMFS4") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26224", "RU000A0ZYUA9", new DateTime(2017, 12, 6), new DateTime(2029, 5, 23), 0.069m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26224RMFS4") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26228", "RU000A100A82", new DateTime(2019, 4, 24), new DateTime(2030, 4, 10), 0.0765m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26218RMFS6") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26218", "RU000A0JVW48", new DateTime(2015, 10, 7), new DateTime(2031, 9, 17), 0.085m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26235RMFS0") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26235", "RU000A1028E3", new DateTime(2020, 9, 23), new DateTime(2031, 3, 12), 0.059m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26241RMFS8") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26241", "RU000A105FZ9", new DateTime(2022, 11, 30), new DateTime(2032, 11, 17), 0.095m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26244RMFS2") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26244", "RU000A1074G2", new DateTime(2023, 9, 27), new DateTime(2034, 3, 15), 0.1125m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26239RMFS2") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26239", "RU000A103901", new DateTime(2021, 8, 4), new DateTime(2031, 7, 23), 0.069m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26221RMFS0") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26221", "RU000A0JXFM1", new DateTime(2016, 10, 12), new DateTime(2033, 3, 23), 0.077m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26225RMFS1") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26225", "RU000A0ZYUB7", new DateTime(2017, 11, 29), new DateTime(2034, 5, 10), 0.0725m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26233RMFS5") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26233", "RU000A101F94", new DateTime(2020, 2, 5), new DateTime(2035, 7, 18), 0.061m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26240RMFS0") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26240", "RU000A103BR0", new DateTime(2021, 8, 18), new DateTime(2036, 7, 30), 0.07m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26243RMFS4") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26243", "RU000A106E90", new DateTime(2023, 6, 7), new DateTime(2038, 5, 19), 0.098m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26230RMFS1") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26230", "RU000A100EF5", new DateTime(2019, 4, 10), new DateTime(2039, 3, 16), 0.077m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26238RMFS4") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26238", "RU000A1038V6", new DateTime(2021, 6, 9), new DateTime(2041, 5, 15), 0.071m);
        SBondList.Add(SBnd);


        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26245RMFS9") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26245", "RU000A108EG6", new DateTime(2024, 10, 9), new DateTime(2035, 9, 26), 0.12m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26246RMFS7") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26246", "RU000A108EE1", new DateTime(2024, 9, 25), new DateTime(2036, 3, 12), 0.12m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26247RMFS5") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26247", "RU000A108EF8", new DateTime(2024, 5, 29), new DateTime(2039, 5, 11), 0.1225m);
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU26248RMFS3") && (s.Board == ExchangeBoard.MicexTqob)));
        SBnd.CreateRegularOFZ("OFZ_26248", "RU000A108EH4", new DateTime(2024, 6, 5), new DateTime(2040, 5, 16), 0.1225m);
        SBondList.Add(SBnd);

        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29014RMFS6") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2026, 3, 25)
        };

        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29007RMFS0") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2027, 3, 3)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29020RMFS3") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2027, 9, 22)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29015RMFS3") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2028, 10, 18)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29019RMFS5") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2029, 7, 18)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29008RMFS8") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2029, 10, 3)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29013RMFS8") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2030, 9, 18)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29021RMFS1") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2030, 11, 27)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29018RMFS7") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2031, 11, 26)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29009RMFS6") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2032, 5, 5)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29017RMFS9") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2032, 8, 25)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29022RMFS9") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2033, 7, 20)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29023RMFS7") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2034, 8, 24)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29010RMFS4") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2034, 12, 6)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29024RMFS5") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2035, 4, 18)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU29025RMFS2") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2037, 8, 12)
        };
        SBondList.Add(SBnd);

        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU52002RMFS1") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2028, 2, 2)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU52003RMFS9") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2030, 7, 17)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU52004RMFS7") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2032, 3, 17)
        };
        SBondList.Add(SBnd);
        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU52005RMFS4") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2033, 5, 11)
        };
        SBondList.Add(SBnd);

        SBnd = new SBond(connector.Securities.FirstOrDefault(s => (s.Code == "SU46020RMFS2") && (s.Board == ExchangeBoard.MicexTqob)))
        {
            Maturity = new DateTime(2036, 2, 6)
        };
        SBondList.Add(SBnd);

        quoteStrategyVolume = (decimal)QuoteVolume.Value;
        quoteSizeStrategyVolume = (decimal)QuoteSizeVolume.Value;
        skipVolume = (decimal)SkipSizeVolume.Value;

        curDate = MyHelper.GetNextWorkingDay(DateTime.Today, 1, ProgramPath + "RedArrowData.db");

        BondList.ForEach(security =>
        {
            string bndName = security.Code.Substring(2, 5);

            BndPrice = OfzCurve.GetNode(security).ModelPrice;
            DecimalUpDown decUpD = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bndName);

            if (!decUpD.IsNull())
            {
                decUpD.Value = BndPrice;
            }

            LongUpDown SmallBidVolUpD = (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallBidVolume_" + bndName);

            if (!SmallBidVolUpD.IsNull())
                SmallBidVolUpD.Value = (long)quoteSmallStrategyBidVolume;

            LongUpDown SmallOfferVolUpD = (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOfferVolume_" + bndName);

            if (!SmallOfferVolUpD.IsNull())
                SmallOfferVolUpD.Value = (long)quoteSmallStrategyOfferVolume;

            LongUpDown WorkVolUpD = (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bndName);

            if (!WorkVolUpD.IsNull())
                WorkVolUpD.Value = (long)quoteStrategyVolume;

            IntegerUpDown SmallOffset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOffset_" + bndName);

            if (!SmallOffset.IsNull())
                SmallOffset.Value = 0;

            IntegerUpDown Offset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bndName);

            if (!Offset.IsNull())
                Offset.Value = 0;

            IntegerUpDown Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName);
            IntegerUpDown Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName);

            SBnd = SBondList.FirstOrDefault(s => s.UnderlyingSecurity.Code == security.Code);

            if (!SBnd.IsNull())
            {
                decimal yield = SBnd.GetYieldForPrice(curDate, BndPrice / 100);

                if (yield > 0)  //Regular bonds
                {
                    if (!Lowlimit.IsNull())
                    {
                        Lowlimit.Value =
                            (int)
                                ((BndPrice / 100 - SBnd.GetPriceFromYield(curDate, yield + lowYieldLimit / 10000, true)) *
                                 10000);

                        if (Lowlimit.Value < 9)
                            Lowlimit.Value = 9;
                        if (Lowlimit.Value > lowLimit * 100)
                            Lowlimit.Value = (int)(lowLimit * 100);
                    }

                    if (!Highlimit.IsNull())
                    {
                        Highlimit.Value =
                            (int)
                                ((BndPrice / 100 - SBnd.GetPriceFromYield(curDate, yield + highYieldLimit / 10000, true)) *
                                 10000);

                        if (Highlimit.Value < 11)
                            Highlimit.Value = 11;
                        if (Highlimit.Value > highLimit * 100)
                            Highlimit.Value = (int)(highLimit * 100);
                    }

                    if ((SBnd.Maturity - curDate).Days < 400)
                        WorkVolUpD.Value = (long?)quoteStrategyVolume;
                    else if ((SBnd.Maturity - curDate).Days < 1100)
                        WorkVolUpD.Value = (long?)quoteStrategyVolume;
                    else if ((SBnd.Maturity - curDate).Days < 1500)
                        WorkVolUpD.Value = (long?)quoteStrategyVolume;
                    else
                        WorkVolUpD.Value = (long?)quoteStrategyVolume;
                }
                else
                {
                    if (OfzCodesIlliquid.Contains(SBnd.UnderlyingSecurity.Code))
                    {
                        if ((SBnd.Maturity - curDate).Days < 300)
                        {
                            WorkVolUpD.Value = 1000;
                            Lowlimit.Value = (int)(lowLimit * 100);
                            Highlimit.Value = (int)(highLimit * 100);
                        }
                        else
                        {
                            WorkVolUpD.Value = 1000;
                            Lowlimit.Value = (int)(lowLimit * 2 * 100);
                            Highlimit.Value = (int)(highLimit * 2 * 100);
                        }
                    }
                    else
                    {
                        if ((SBnd.Maturity - curDate).Days < 500)
                        {
                            WorkVolUpD.Value = 2000;
                            Lowlimit.Value = (int)(lowLimit / 2 * 100);
                            Highlimit.Value = (int)(highLimit / 2 * 100);
                        }

                        else if ((SBnd.Maturity - curDate).Days < 2000)
                        {
                            WorkVolUpD.Value = 2000;
                            Lowlimit.Value = (int)(lowLimit / 1.5m * 100);
                            Highlimit.Value = (int)(highLimit / 1.5m * 100);
                        }

                        else
                        {
                            WorkVolUpD.Value = 2000;
                            Lowlimit.Value = (int)(lowLimit / 1.5m * 100);
                            Highlimit.Value = (int)(highLimit / 1.5m * 100);
                        }
                    }
                }
            }
            else
            {
                if (!Lowlimit.IsNull())
                    Lowlimit.Value = (int)(lowLimit * 100);

                if (!Highlimit.IsNull())
                    Highlimit.Value = (int)(highLimit * 100);
            }
        });

        btnStart.IsEnabled = true;
        X2.IsEnabled = true;
        Del2.IsEnabled = true;
        SPlus.IsEnabled = true;
        SMinus.IsEnabled = true;
        Reset_All.IsEnabled = true;

        BondList.ForEach(security =>
        {
            string bndName = security.Code.Substring(2, 5);
            Button btnRst = (Button)LogicalTreeHelper.FindLogicalNode(MyProgram, "Reset_" + bndName);

            if (!btnRst.IsNull())
                btnRst.IsEnabled = true;
        });

        System.Windows.MessageBox.Show("Data loaded!!!");
    }

    [Obsolete]
    private void StartClick(object sender, RoutedEventArgs e)
    {
        if (!btnStart.IsEnabled)
            return;

        if (!BondList.Any())
            return;

        if (OfzCurve.Length == 0)
            return;

        SBondPositionsList.Clear();
        SBondSizePositionsList.Clear();
        SBondSmallPositionsList.Clear();

        bondPositionTraded = 0;
        bondSizePositionTraded = 0;
        bondSmallPositionTraded = 0;
        bondOutOfRangePositionTraded = 0;

        BondList.ForEach(security =>
        {
            Subscription sub = connector.SubscribeMarketDepth(security);

            string bndName = security.Code.Substring(2, 5);
            DecimalUpDown decUpD = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bndName);

            if (!decUpD.IsNull())
            {
                long? WorkVol =
                    ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bndName)).Value;
                long? SmallBidVol =
                  ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallBidVolume_" + bndName)).Value;
                long? SmallOfferVol =
                  ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOfferVolume_" + bndName)).Value;
                int? Lowlimit =
                    ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName)).Value;
                int? Highlimit =
                    ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName)).Value;
                int? SmallOffset =
                    ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOffset_" + bndName)).Value;
                int? Offset =
                    ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bndName)).Value;
                bool? IsSmall =
                    ((CheckBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "IsMM_" + bndName)).IsChecked;

                SBondPositionsList.Add(new SecurityPosition(security, "Quote", (decimal)Lowlimit / 100,
                    (decimal)Highlimit / 100, (decimal)WorkVol, (decimal)WorkVol, (decimal)Offset / 100));

                if ((bool)IsSmall)
                {
                    SBondSmallPositionsList.Add(new SecurityPosition(security, "Small", (decimal)(0.0301), (decimal)(Lowlimit - 0.1) / 100, (decimal)SmallBidVol, (decimal)SmallOfferVol, (decimal)SmallOffset / 100));
                }

                if (OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code))
                    SBondSizePositionsList.Add(new SecurityPosition(security, "Size", (decimal)(Highlimit + 0.1) / 100, (decimal)(Lowlimit + Highlimit) / 100, quoteSizeStrategyVolume, quoteSizeStrategyVolume, 0m));

            }
            else
            {
                SBondPositionsList.Add(new SecurityPosition(security, "Quote", lowLimit, highLimit, quoteStrategyVolume, quoteStrategyVolume, 0m));

                if (OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code))
                    SBondSizePositionsList.Add(new SecurityPosition(security, "Size", highLimit, lowLimit + highLimit, quoteSizeStrategyVolume, quoteSizeStrategyVolume, 0m));
            }
        });

        _ordersForQuoteBuyReregister = new Dictionary<string, Order>();
        _ordersForQuoteSellReregister = new Dictionary<string, Order>();

        connector.OrderBookReceived += OnProcessMDepthChangedForQuoteStrategy;
        connector.OrderBookReceived += OnProcessOutOfRangeCheck;
        connector.NewMyTrade += OnProcessNewTrade;
        connector.OrderChanged += OnProcessOrderCancelled;

        fileWatcher.Path = ProgramPath;
        fileWatcher.NotifyFilter = NotifyFilters.LastWrite;
        fileWatcher.Filter = "RedArrowData.db";
        fileWatcher.Changed += new FileSystemEventHandler(OnDatabaseChanged);
        fileWatcher.EnableRaisingEvents = true;

        btnStop.IsEnabled = true;
        btnStart.IsEnabled = false;
    }

    private void OnDatabaseChanged(object source, FileSystemEventArgs a)
    {
        try
        {
            OfzCurve.GetCurveFromDb(ProgramPath + "RedArrowData.db", connector);

            if (OfzCurve.Length == 0)
            {
                this.GuiAsync(() => btnStop.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)));
                return;
            }

            BondList.ForEach(security =>
            {
                if (OderBookList.ContainsKey(security))
                {
                    Subscription sub = connector.FindSubscriptions(security, DataType.MarketDepth).Where(s => s.SubscriptionMessage.To == null && s.State.IsActive()).FirstOrDefault();
                    OnProcessMDepthChangedForQuoteStrategy(sub, OderBookList[security]);
                }

            });

            connector.AddWarningLog("Curve changed");
        }
        catch (IOException)
        {
            fileWatcher.EnableRaisingEvents = true;
        }
        finally
        {
            //   fileWatcher.EnableRaisingEvents = true;
        }
    }

    private void OnProcessMDepthChangedForQuoteStrategy(Subscription subscription, IOrderBookMessage depth)
    {
        Order tmpOrder;
        Order newOrder;
        IOrderBookMessage tmpDepth;
        decimal price;

        Security sec = connector.Securities.FirstOrDefault(s => s.ToSecurityId() == depth.SecurityId);

        SecurityPosition SbPos = SBondPositionsList.FirstOrDefault(sp => sp.Sec.Equals(sec));

        if (!SbPos.IsNull() && !sec.IsNull())
        {
            if (!_ordersForQuoteBuyReregister.ContainsKey(sec.Code) && !depth.Bids.IsNull() && !connector.Orders.Any(s => ((s.State == OrderStates.Pending) && (!s.Comment.IsNull()) && (s.Comment.ContainsIgnoreCase("Quote")) && (s.Security.Code == sec.Code) && (s.Side == Sides.Buy))))
            {
                IEnumerable<Order> Orders = connector.Orders.Where(s => (s.State == OrderStates.Active) && (s.Security.Code == sec.Code) && (!s.Comment.IsNull()) && (s.Comment.ContainsIgnoreCase("Quote")) && (s.Side == Sides.Buy));

                if (Orders.IsEmpty()) //if there is no orders in stakan
                {
                    price = MyHelper.GetBestConditionPrice(sec, depth, OfzCurve.GetNode(sec).ModelPrice + SbPos.Offset, -SbPos.LowLimit, -SbPos.HighLimit, 2.101m * SbPos.BidVolume);
                    if (price > 0)
                    {
                        Order ord = new()
                        {
                            Security = sec,
                            Portfolio = MyPortf,
                            Price = price,
                            Side = Sides.Buy,
                            Comment = "Quote",
                            IsMarketMaker = OfzCodes.Contains(sec.Code),
                            Volume = SbPos.BidVolume,
                            ClientCode = ClCode,
                        };
                        connector.RegisterOrder(ord);
                        connector.AddWarningLog("Order buy registered new: ins ={0}, price = {1}, volume = {2}", sec, price, SbPos.BidVolume);
                    }
                }
                else
                {
                    tmpOrder = Orders.First();
                    tmpDepth = (IOrderBookMessage)depth.Clone();

                    int Len = tmpDepth.Bids.Length;
                    for (int i = 0; i < Len; i++)
                    {
                        if ((tmpDepth.Bids[i].Price == tmpOrder.Price) && (tmpDepth.Bids[i].Volume >= tmpOrder.Balance))
                        {
                            tmpDepth.Bids[i].Volume = tmpDepth.Bids[i].Volume - tmpOrder.Balance;
                            break;
                        }
                    }

                    price = MyHelper.GetBestConditionPrice(sec, tmpDepth, OfzCurve.GetNode(sec).ModelPrice + SbPos.Offset, -SbPos.LowLimit, -SbPos.HighLimit, 2.101m * SbPos.BidVolume);

                    if ((price > 0) && ((price != tmpOrder.Price) || (tmpOrder.Balance != SbPos.BidVolume)))
                    {
                        newOrder = new Order()
                        {
                            Security = sec,
                            Portfolio = MyPortf,
                            Price = price,
                            Side = Sides.Buy,
                            Comment = "Quote",
                            IsMarketMaker = OfzCodes.Contains(sec.Code),
                            Volume = SbPos.BidVolume,
                            ClientCode = ClCode,
                        };
                        _ordersForQuoteBuyReregister.Add(tmpOrder.Security.Code, newOrder);

                        connector.AddWarningLog("Order buy cancelled for reregister: ins ={0}, price = {1}, volume = {2}", sec, tmpOrder.Price, tmpOrder.Volume);
                        connector.CancelOrder(tmpOrder);
                    }

                    Orders.Skip(1).ForEach(s =>
                    {
                        connector.AddWarningLog("Order buy duplication!");
                        if (s.Id != tmpOrder.Id)
                        {
                            connector.AddWarningLog("Duplicate buy order cancelled: ins ={0}, price = {1}, volume = {2}",
                                       s.Security, s.Price, s.Volume);
                            connector.CancelOrder(s);
                        }
                    });
                }

            }

            //only for sell orders
            if (!_ordersForQuoteSellReregister.ContainsKey(sec.Code) && !depth.Asks.IsNull() && !connector.Orders.Any(s => ((s.State == OrderStates.Pending) && (!s.Comment.IsNull()) && (s.Comment.ContainsIgnoreCase("Quote")) && (s.Security.Code == sec.Code) && (s.Side == Sides.Sell))))
            {
                IEnumerable<Order> Orders = connector.Orders.Where(s => (s.State == OrderStates.Active) && (s.Security.Code == sec.Code) && (!s.Comment.IsNull()) && (s.Comment.ContainsIgnoreCase("Quote")) && (s.Side == Sides.Sell));

                if (Orders.IsEmpty()) //if there is no orders in stakan
                {
                    price = MyHelper.GetBestConditionPrice(sec, depth, OfzCurve.GetNode(sec).ModelPrice + SbPos.Offset, SbPos.LowLimit, SbPos.HighLimit, 2.101m * SbPos.OfferVolume);
                    if (price > 0)
                    {
                        Order ord = new()
                        {
                            Security = sec,
                            Portfolio = MyPortf,
                            Price = price,
                            Side = Sides.Sell,
                            Comment = "Quote",
                            IsMarketMaker = OfzCodes.Contains(sec.Code),
                            Volume = SbPos.OfferVolume,
                            ClientCode = ClCode,
                        };

                        connector.RegisterOrder(ord);
                        connector.AddWarningLog("Order sell registered new: ins ={0}, price = {1}, volume = {2}", sec, price, SbPos.OfferVolume);
                    }
                }
                else
                {
                    tmpOrder = Orders.First();
                    tmpDepth = (IOrderBookMessage)depth.Clone();

                    int Len = tmpDepth.Asks.Length;
                    for (int i = 0; i < Len; i++)
                    {
                        if ((tmpDepth.Asks[i].Price == tmpOrder.Price) && (tmpDepth.Asks[i].Volume >= tmpOrder.Balance))
                        {
                            tmpDepth.Asks[i].Volume = tmpDepth.Asks[i].Volume - tmpOrder.Balance;
                            break;
                        }
                    }

                    price = MyHelper.GetBestConditionPrice(sec, tmpDepth, OfzCurve.GetNode(sec).ModelPrice + SbPos.Offset, SbPos.LowLimit, SbPos.HighLimit, 2.101m * SbPos.OfferVolume);

                    if ((price > 0) && ((price != tmpOrder.Price) || (tmpOrder.Balance != SbPos.OfferVolume)))
                    {
                        newOrder = new Order()
                        {
                            Security = sec,
                            Portfolio = MyPortf,
                            Price = price,
                            Side = Sides.Sell,
                            Comment = "Quote",
                            IsMarketMaker = OfzCodes.Contains(sec.Code),
                            Volume = SbPos.OfferVolume,
                            ClientCode = ClCode,
                        };
                        _ordersForQuoteSellReregister.Add(tmpOrder.Security.Code, newOrder);
                        connector.AddWarningLog(" Order sell cancelled for reregister: ins ={0}, price = {1}, volume = {2}", sec, tmpOrder.Price, tmpOrder.Volume);
                        connector.CancelOrder(tmpOrder);
                    }

                    Orders.Skip(1).ForEach(s =>
                    {

                        connector.AddWarningLog("Order sell duplication!");
                        if (s.Id != tmpOrder.Id)
                        {
                            connector.AddWarningLog("Duplicate sell order cancelled: ins ={0}, price = {1}, volume = {2}",
                                       s.Security, s.Price, s.Volume);
                            connector.CancelOrder(s);

                        }
                    });
                }
            }
        }
    }

    private void OnProcessOutOfRangeCheck(Subscription subscription, IOrderBookMessage depth)
    {
        decimal ofrVolume;

        Security sec = connector.Securities.FirstOrDefault(s => s.ToSecurityId() == depth.SecurityId);

        //..................................
        // For bonds
        //...................................

        SecurityPosition SbPos = SBondPositionsList.FirstOrDefault(sp => sp.Sec.Equals(sec));

        if (SbPos.IsNull())
            return;

        if (SbPos.LowLimit > SbPos.HighLimit)
            return;

        IEnumerable<Order> Orders = connector.Orders.Where(s =>
                                 (s.State == OrderStates.Active) && (s.Security.Code == sec.Code) && (!s.Comment.IsNull()) && (s.Comment.ContainsIgnoreCase("Ofr")));

        if (!Orders.IsEmpty() && (Orders.Count() > 4))
            return;

        QuoteChange? bBid = depth.GetBestBid();
        QuoteChange? bAsk = depth.GetBestAsk();

        if ((bBid.IsNull()) || (bAsk.IsNull()))
            return;

        if (bBid.Value.Price > OfzCurve.GetNode(sec).ModelPrice + SbPos.LowLimit + SbPos.HighLimit)
        {
            ofrVolume = 20000;
            if (bBid.Value.Price > OfzCurve.GetNode(sec).ModelPrice + 2 * SbPos.HighLimit)
                ofrVolume = 30000;
            if (bBid.Value.Price > OfzCurve.GetNode(sec).ModelPrice + 3 * SbPos.HighLimit)
                ofrVolume = 50000;

            if (bBid.Value.Volume < ofrVolume)
                ofrVolume = bBid.Value.Volume;

            DeleteAllQuotesByStrategy("Quote");
            DeleteAllQuotesByStrategy("Size");

            Order ord = new()
            {
                Security = sec,
                Portfolio = MyPortf,
                Price = bBid.Value.Price,
                Side = Sides.Sell,
                Comment = "OfRStrategy",
                IsMarketMaker = OfzCodes.Contains(sec.Code),
                Volume = ofrVolume,
                ClientCode = ClCode,
            };

            connector.RegisterOrder(ord);
            connector.AddWarningLog("Order sell registered for OfRStrategy: ins ={0}, price = {1}, volume = {2}", sec, ord.Price, ord.Volume);

            // New logic???
            this.GuiAsync(() => System.Windows.MessageBox.Show(this, "OfR Detected! " + sec.Code));
            connector.OrderBookReceived -= OnProcessOutOfRangeCheck;
            //
        }
        else if (bAsk.Value.Price < OfzCurve.GetNode(sec).ModelPrice - SbPos.LowLimit - SbPos.HighLimit)
        {
            ofrVolume = 20000;
            if (bAsk.Value.Price < OfzCurve.GetNode(sec).ModelPrice - 2 * SbPos.HighLimit)
                ofrVolume = 30000;
            if (bAsk.Value.Price < OfzCurve.GetNode(sec).ModelPrice - 3 * SbPos.HighLimit)
                ofrVolume = 50000;

            if (bAsk.Value.Volume < ofrVolume)
                ofrVolume = bAsk.Value.Volume;

            DeleteAllQuotesByStrategy("Quote");
            DeleteAllQuotesByStrategy("Size");

            Order ord = new()
            {
                Security = sec,
                Portfolio = MyPortf,
                Price = bAsk.Value.Price,
                Side = Sides.Buy,
                Comment = "OfRStrategy",
                IsMarketMaker = OfzCodes.Contains(sec.Code),
                Volume = ofrVolume,
                ClientCode = ClCode,
            };

            connector.RegisterOrder(ord);
            connector.AddWarningLog("Order buy registered for OfRStrategy: ins ={0}, price = {1}, volume = {2}", sec, ord.Price, ord.Volume);

            // New logic???
            this.GuiAsync(() => System.Windows.MessageBox.Show(this, "OfR Detected! " + sec.Code));
            connector.OrderBookReceived -= OnProcessOutOfRangeCheck;
            //
        }
    }

    private void OnProcessOrderCancelled(Order order)
    {
        if (!order.Comment.IsNull() && order.Comment.ContainsIgnoreCase("Quote"))
        {
            if (order.State == OrderStates.Done && order.IsCanceled() && (_ordersForQuoteBuyReregister.ContainsKey(order.Security.Code)))
            {
                Order regOrd = _ordersForQuoteBuyReregister.TryGetValue(order.Security.Code);
                connector.RegisterOrder(regOrd);
                _ordersForQuoteBuyReregister.Remove(order.Security.Code);
                connector.AddWarningLog("Order buy registered from table: ins ={0}, price = {1}, volume = {2}", regOrd.Security, regOrd.Price, regOrd.Volume);
            }

            if (order.State == OrderStates.Done && order.IsCanceled() && (_ordersForQuoteSellReregister.ContainsKey(order.Security.Code)))
            {
                Order regOrd = _ordersForQuoteSellReregister.TryGetValue(order.Security.Code);
                connector.RegisterOrder(regOrd);
                _ordersForQuoteSellReregister.Remove(order.Security.Code);
                connector.AddWarningLog("Order sell registered from table: ins ={0}, price = {1}, volume = {2}", regOrd.Security, regOrd.Price, regOrd.Volume);
            }
        }
    }

    async private void OnProcessNewTrade(MyTrade tr)
    {
        if (TradesList.Contains(tr.Trade.Id))
        {
            connector.AddWarningLog("Trade duplication! Bond name ={0}, size = {1}", tr.Order.Security, tr.Trade.Volume);
            await TelBot.SendMessage(81746878, "Trade duplication!");
        }
        else
        {
            TradesList.Add(tr.Trade.Id);

            try
            {
                await TelBot.SendMessage(81746878, $"New {tr.Order.Side} trade done in Sec name ={tr.Order.Security}, size = {tr.Trade.Volume}, price = {tr.Trade.Price}, strategy = {tr.Order.Comment}, dealID = {tr.Trade.Id}");
            }
            catch (System.Net.Http.HttpRequestException)
            {
                this.GuiAsync(() => System.Windows.MessageBox.Show(this, "TelBot exeption!"));
            }

            if ((!tr.Order.Comment.IsEmpty()) && (tr.Order.Comment.ContainsIgnoreCase("Quote")))
            {
                SecurityPosition SbPos = SBondPositionsList.FirstOrDefault(sb => (sb.Sec.Code == tr.Order.Security.Code));
                if (!SbPos.IsNull())
                {

                    if (tr.Order.Side == Sides.Buy)
                    {
                        SbPos.Position += tr.Trade.Volume;
                        SbPos.Offset = SbPos.Offset - 0.5m * tr.Trade.Volume / SbPos.BidVolume * SbPos.LowLimit;
                    }
                    else
                    {
                        SbPos.Position -= tr.Trade.Volume;
                        SbPos.Offset = SbPos.Offset + 0.5m * tr.Trade.Volume / SbPos.OfferVolume * SbPos.LowLimit;
                    }

                    bondPositionTraded += Math.Abs(tr.Trade.Volume);

                    connector.AddWarningLog("New trade done in bond name ={0}, size = {1}", tr.Order.Security, tr.Trade.Volume);

                    Subscription sub = connector.FindSubscriptions(tr.Order.Security, DataType.MarketDepth).Where(s => s.SubscriptionMessage.To == null && s.State.IsActive()).FirstOrDefault();
                    OnProcessMDepthChangedForQuoteStrategy(sub, OderBookList[tr.Order.Security]);
                }
            }

            if ((!tr.Order.Comment.IsEmpty()) && (tr.Order.Comment.ContainsIgnoreCase("OfR")))
            {
                bondOutOfRangePositionTraded += Math.Abs(tr.Trade.Volume);

                connector.AddWarningLog("New trade done in bond name (OfrStrategy) ={0}, size = {1}", tr.Order.Security, tr.Trade.Volume);
            }
        }


        if ((bondPositionTraded >= 100000) || (bondSizePositionTraded >= 200000) || (bondSmallPositionTraded >= 50000) || (bondOutOfRangePositionTraded >= 100000))
        {
            connector.AddWarningLog("Program suspended because of limit trade reached");

            this.GuiAsync(() => System.Windows.MessageBox.Show(this, "Limit reached!"));

            connector.OrderBookReceived -= OnProcessMDepthChangedForQuoteStrategy;
            connector.OrderBookReceived -= OnProcessOutOfRangeCheck;

            connector.OrderChanged -= OnProcessOrderCancelled;

            System.Threading.Thread.Sleep(200);

            this.GuiAsync(() => btnStop.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)));

            return;
        }



    }

    private void StopClick(object sender, RoutedEventArgs e)
    {
        if (!btnStop.IsEnabled)
            return;

        connector.OrderBookReceived -= OnProcessMDepthChangedForQuoteStrategy;
        connector.OrderBookReceived -= OnProcessOutOfRangeCheck;
        connector.OrderChanged -= OnProcessOrderCancelled;

        DeleteAllQuotesByStrategy("Quote");

        _ordersForQuoteBuyReregister = null;
        _ordersForQuoteSellReregister = null;

        bondPositionTraded = 0;
        bondSizePositionTraded = 0;
        bondSmallPositionTraded = 0;
        bondOutOfRangePositionTraded = 0;

        fileWatcher.EnableRaisingEvents = false;
        btnStop.IsEnabled = false;
        btnStart.IsEnabled = true;
    }

    private void ResetClick(object sender, RoutedEventArgs e)
    {
        Button btn;
        btn = sender as Button;
        string bondName;

        if (!Reset_All.IsEnabled)
            return;

        if (sender.IsNull())
            bondName = "All";
        else
        {
            bondName = btn.Name;
            bondName = bondName.Substring(bondName.Length - 5);
        }

        quoteSizeStrategyVolume = (decimal)QuoteSizeVolume.Value;
        skipVolume = (decimal)SkipSizeVolume.Value;

        if (bondName.ContainsIgnoreCase("All"))
        {
            DeleteAllQuotesByStrategy("Size");
            DeleteAllQuotesByStrategy("Small");
            DeleteAllQuotesByStrategy("Quote");

            SBondPositionsList.Clear();
            SBondSizePositionsList.Clear();
            SBondSmallPositionsList.Clear();

            BondList.ForEach(security =>
            {
                string bndName = security.Code.Substring(2, 5);
                DecimalUpDown decUpD = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bndName);

                if (!decUpD.IsNull())
                {
                    long? WorkVol =
                      ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bndName)).Value;
                    long? SmallBidVol =
                      ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallBidVolume_" + bndName)).Value;
                    long? SmallOfferVol =
                      ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOfferVolume_" + bndName)).Value;
                    int? Lowlimit =
                      ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName)).Value;
                    int? Highlimit =
                      ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName)).Value;
                    int? SmallOffset =
                      ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOffset_" + bndName)).Value;
                    int? Offset =
                      ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bndName)).Value;
                    bool? IsSmall =
                      ((CheckBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "IsMM_" + bndName)).IsChecked;

                    SBondPositionsList.Add(new SecurityPosition(security, "Quote", (decimal)Lowlimit / 100,
                      (decimal)Highlimit / 100, (decimal)WorkVol, (decimal)WorkVol, (decimal)Offset / 100));

                    if ((bool)IsSmall)
                    {
                        SBondSmallPositionsList.Add(new SecurityPosition(security, "Small", (decimal)(0.0301), (decimal)(Lowlimit - 0.1) / 100, (decimal)SmallBidVol, (decimal)SmallOfferVol, (decimal)SmallOffset / 100));
                    }

                    if (OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code))
                        SBondSizePositionsList.Add(new SecurityPosition(security, "Size", (decimal)(Highlimit + 0.1) / 100, (decimal)(Lowlimit + Highlimit) / 100, quoteSizeStrategyVolume, quoteSizeStrategyVolume, 0m));

                }
                else
                {
                    SBondPositionsList.Add(new SecurityPosition(security, "Quote", lowLimit, highLimit, quoteStrategyVolume, quoteStrategyVolume, 0m));


                    if (OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code))
                        SBondSizePositionsList.Add(new SecurityPosition(security, "Size", highLimit, lowLimit + highLimit, quoteSizeStrategyVolume, quoteSizeStrategyVolume, 0m));
                }

                Subscription sub = connector.FindSubscriptions(security, DataType.MarketDepth).Where(s => s.SubscriptionMessage.To == null && s.State.IsActive()).FirstOrDefault();
                OnProcessMDepthChangedForQuoteStrategy(sub, OderBookList[security]);
            });
        }

        else
        {
            SecurityPosition SbPos = SBondPositionsList.FirstOrDefault(sp => sp.Sec.Code.ContainsIgnoreCase(bondName));
            if (!SbPos.IsNull())
                SBondPositionsList.Remove(SbPos);

            SecurityPosition SbSizePos = SBondSizePositionsList.FirstOrDefault(sp => sp.Sec.Code.ContainsIgnoreCase(bondName));
            if (!SbSizePos.IsNull())
                SBondSizePositionsList.Remove(SbSizePos);

            SecurityPosition SbSmallPos = SBondSmallPositionsList.FirstOrDefault(sp => sp.Sec.Code.ContainsIgnoreCase(bondName));
            if (!SbSmallPos.IsNull())
                SBondSmallPositionsList.Remove(SbSmallPos);

            Security security = BondList.FirstOrDefault(sec => sec.Code.ContainsIgnoreCase(bondName));

            DecimalUpDown decUpD = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bondName);

            if (!decUpD.IsNull())
            {
                long? WorkVol =
                  ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bondName)).Value;
                long? SmallBidVol =
                  ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallBidVolume_" + bondName)).Value;
                long? SmallOfferVol =
                  ((LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOfferVolume_" + bondName)).Value;
                int? Lowlimit =
                  ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bondName)).Value;
                int? Highlimit =
                  ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bondName)).Value;
                int? SmallOffset =
                  ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOffset_" + bondName)).Value;
                int? Offset =
                  ((IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bondName)).Value;
                bool? IsSmall =
                  ((CheckBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "IsMM_" + bondName)).IsChecked;

                SBondPositionsList.Add(new SecurityPosition(security, "Quote", (decimal)Lowlimit / 100, (decimal)Highlimit / 100, (decimal)WorkVol, (decimal)WorkVol, (decimal)Offset / 100));

                if ((bool)IsSmall)
                {
                    SBondSmallPositionsList.Add(new SecurityPosition(security, "Small", (decimal)(0.0301), (decimal)(Highlimit - 0.1) / 100, (decimal)SmallBidVol, (decimal)SmallOfferVol, (decimal)SmallOffset / 100));
                }

                if (OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code))
                    SBondSizePositionsList.Add(new SecurityPosition(security, "Size", (decimal)(Highlimit + 0.1) / 100, (decimal)(Lowlimit + Highlimit) / 100, quoteSizeStrategyVolume, quoteSizeStrategyVolume, 0m));

            }
            else
            {
                SBondPositionsList.Add(new SecurityPosition(security, "Quote", lowLimit, highLimit, quoteStrategyVolume, quoteStrategyVolume, 0m));

                if (OfzCodes.Contains(security.Code) || OfzCodesNew.Contains(security.Code))
                    SBondSizePositionsList.Add(new SecurityPosition(security, "Size", highLimit, lowLimit + highLimit, quoteSizeStrategyVolume, quoteSizeStrategyVolume, 0m));
            }

            Subscription sub = connector.FindSubscriptions(security, DataType.MarketDepth).Where(s => s.SubscriptionMessage.To == null && s.State.IsActive()).FirstOrDefault();
            OnProcessMDepthChangedForQuoteStrategy(sub, OderBookList[security]);
        }
    }

    private void DeleteAllQuotesByStrategy(string strategy)
    {
        IEnumerable<Order> orders = null;
        orders = connector.Orders.Where(s => (s.State == OrderStates.Active));

        if (strategy.IsEmpty())
        {
            foreach (Order order in orders)
            {
                connector.CancelOrder(order);
                connector.AddWarningLog("Order cancelled: ins ={0}, price = {1}, volume = {2}", order.Security, order.Price, order.Volume);
            }
        }
        else
        {
            foreach (Order order in orders)
            {
                if ((!order.Comment.IsEmpty()) && order.Comment.ContainsIgnoreCase(strategy))
                    connector.CancelOrder(order);

                connector.AddWarningLog("Order cancelled: ins ={0}, price = {1}, volume = {2}", order.Security, order.Price, order.Volume);
            }
        }
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (connector != null)
        {
            DeleteAllQuotesByStrategy("Quote");
            connector.Dispose();
        }

        base.OnClosing(e);
    }

    //test function
    private void PlaceOrderClick(object sender, RoutedEventArgs e)
    {
        Security SBndSecurity = new();
        SBond SBnd = new();

        if (OfzCurve.Length == 0)
            return;

        SBndSecurity = connector.Securities.FirstOrDefault(s => (s.Code == "SU26205RMFS3") && (s.Board == ExchangeBoard.MicexTqob));
        SBnd = new SBond(SBndSecurity);
        Order _testOrder = new()
        {
            Security = SBndSecurity,
            Portfolio = connector.Portfolios.FirstOrDefault(p => p.Name == PortName),
            Direction = Sides.Buy,
            Price = OfzCurve.GetNode(SBndSecurity).ModelPrice - 0.2m,
            IsMarketMaker = false,
            ClientCode = ClCode,
            Volume = 1,
            Comment = "test",
        };
        connector.RegisterOrder(_testOrder);
    }

    private void SaveParamsClick(object sender, RoutedEventArgs e)
    {
        List<string> lines = new();

        if (!BondList.Any())
            return;

        BondList.ForEach(security =>
        {
            string bndName = security.Code.Substring(2, 5);

            TextBox txtBox = (TextBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "Bond_" + bndName);

            if (!txtBox.IsNull())
            {
                LongUpDown WorkVolUpD =
                    (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bndName);
                LongUpDown SmallBidVolUpD =
                    (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallBidVolume_" + bndName);
                LongUpDown SmallOfferVolUpD =
                    (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOfferVolume_" + bndName);
                IntegerUpDown SmallOffset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOffset_" + bndName);
                IntegerUpDown Offset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bndName);
                IntegerUpDown Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName);
                IntegerUpDown Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName);
                CheckBox IsSize = (CheckBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "IsMM_" + bndName);

                string line = bndName + " " + SmallBidVolUpD.Value.ToString() + " " + SmallOfferVolUpD.Value.ToString() + " " +
                              WorkVolUpD.Value.ToString() + " " + SmallOffset.Value.ToString() + " " + Offset.Value.ToString() + " " +
                              Lowlimit.Value.ToString() + " " + Highlimit.Value.ToString() + " " + IsSize.IsChecked.ToString();

                lines.Add(line);
            }
        });

        File.WriteAllLines(ProgramPath + "Parameters.txt", lines);
    }

    private void LoadParamsClick(object sender, RoutedEventArgs e)
    {
        if (!File.Exists(ProgramPath + "Parameters.txt"))
            return;

        IEnumerable<string> lines = File.ReadLines(ProgramPath + "Parameters.txt");

        foreach (string line in lines)
        {
            string bndName = line.Split(" ").First();

            LongUpDown SmallBidVolUpD =
                (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallBidVolume_" + bndName);
            SmallBidVolUpD.Value = long.Parse(line.Split(" ").Skip(1).First());

            LongUpDown SmallOfferVolUpD =
                (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOfferVolume_" + bndName);
            SmallOfferVolUpD.Value = long.Parse(line.Split(" ").Skip(2).First());

            LongUpDown WorkVolUpD =
                (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bndName);
            WorkVolUpD.Value = long.Parse(line.Split(" ").Skip(3).First());

            IntegerUpDown SmallOffset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "SmallOffset_" + bndName);
            SmallOffset.Value = int.Parse(line.Split(" ").Skip(4).First());

            IntegerUpDown Offset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bndName);
            Offset.Value = int.Parse(line.Split(" ").Skip(5).First());

            IntegerUpDown Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName);
            Lowlimit.Value = int.Parse(line.Split(" ").Skip(6).First());

            IntegerUpDown Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName);
            Highlimit.Value = int.Parse(line.Split(" ").Skip(7).First());

            CheckBox IsSize = (CheckBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "IsMM_" + bndName);
            IsSize.IsChecked = line.Split(" ").Skip(8).First().Equals("True");
        }
    }

    private void X2Click(object sender, RoutedEventArgs e)
    {
        BondList.ForEach(security =>
        {
            string bndName = security.Code.Substring(2, 5);
            DecimalUpDown decUpD = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bndName);

            if (!decUpD.IsNull())
            {
                var Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName);
                var Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName);
                Lowlimit.Value = Lowlimit.Value * 2;
                Highlimit.Value = Highlimit.Value * 2;

            }
        });

        lowLimit = lowLimit * 2;
        highLimit = highLimit * 2;
    }

    private void Del2Click(object sender, RoutedEventArgs e)
    {
        BondList.ForEach(security =>
        {
            string bndName = security.Code.Substring(2, 5);
            DecimalUpDown decUpD = (DecimalUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Price_" + bndName);

            if (!decUpD.IsNull())
            {
                IntegerUpDown Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName);
                IntegerUpDown Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName);
                Lowlimit.Value = Lowlimit.Value / 2;
                Highlimit.Value = Highlimit.Value / 2;

            }
        });

        lowLimit = lowLimit / 2;
        highLimit = highLimit / 2;
    }

    //parallel shift of the curve on yildChange value in bp
    public void ShiftCurve(decimal yieldChange)
    {
        OfzCurve.BondList.ForEach(bnd =>
        {
            SBond SBnd = SBondList.FirstOrDefault(s => s.UnderlyingSecurity.Code == bnd.MicexCode);

            if (!SBnd.IsNull())
            {
                var yield = SBnd.GetYieldForPrice(OfzCurve.CurveDate, bnd.ModelPrice / 100);
                if (yield > 0) //Regular bonds
                {
                    bnd.ModelPrice = Math.Round(100 * SBnd.GetPriceFromYield(OfzCurve.CurveDate, yield + yieldChange / 10000, true), 2);
                }
            }
        });
    }

    private void ShiftPlusClick(object sender, RoutedEventArgs e)
    {
        if (OfzCurve.IsNull())
            return;

        ShiftCurve(1m);

        var mdepths = new List<MarketDepth>();

        BondList.ForEach(security =>
        {
            //      mdepths.Add(QTrader.GetMarketDepth(security));
        });

        connector.AddWarningLog("Curve changed");
    }

    private void ShiftMinusClick(object sender, RoutedEventArgs e)
    {
        if (OfzCurve.IsNull())
            return;
        ShiftCurve(-1m);

        var mdepths = new List<MarketDepth>();

        BondList.ForEach(security =>
        {
            //      mdepths.Add(QTrader.GetMarketDepth(security));
        });

        connector.AddWarningLog("Curve changed");
    }

    async Task BotOnMessageReceived(Telegram.Bot.Types.Message message, UpdateType type)
    {
        if (message == null || message.Type != MessageType.Text) return;

        TimeSpan dt = DateTime.UtcNow - message.Date;

        if (dt.TotalSeconds > 30) return;

        if (message.From.Id != 81746878)
        {
            await TelBot.SendMessage(81746878, "Somebody else is trying to send message!");
            return;
        }

        if (message.Text.Equals("/x2spread"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => X2Click(null, null));
            });

            await TelBot.SendMessage(81746878, "Spreads increased 2 times");
        }

        if (message.Text.Equals("/del2spread"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => Del2Click(null, null));
            });

            await TelBot.SendMessage(81746878, "Spreads decreased 2 times");

        }

        if (message.Text.Equals("/shiftcurveup"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => ShiftPlusClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Curve shifted parallel by +1 bp");
        }

        if (message.Text.Equals("/shiftcurvedown"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => ShiftMinusClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Curve shifted parallel by -1 bp");
        }

        if (message.Text.Equals("/reset"))
        {

            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => ResetClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Reset done");
        }

        if (message.Text.Equals("/saveparams"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => SaveParamsClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Parameters Saved");
        }

        if (message.Text.Equals("/loadparams"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => LoadParamsClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Parameters Loaded");

        }

        if (message.Text.Equals("/start"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => StartClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Program Started!!!");
        }

        if (message.Text.Equals("/stop"))
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() => StopClick(null, null));
            });

            await TelBot.SendMessage(81746878, "Program Suspended!!!");
        }

        if (message.Text.Contains("/sellbond"))
        {
            bool flag = true;
            string[] par = message.Text.Split(" ");

            if (par.Length != 4)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {

                        var sec = connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + par.Skip(1).First())) && (s.Board == ExchangeBoard.MicexTqob));

                        if (decimal.TryParse(par.Skip(2).First(), out decimal price) &&
                            (decimal.TryParse(par.Skip(3).First(), out decimal volume)) && (!sec.IsNull()))
                        {
                            if (Math.Abs(OfzCurve.GetNode(sec).ModelPrice - price) > 2)
                                flag = false;
                            if ((volume <= 0) || (volume > 10000))
                                flag = false;
                            if (flag)
                            {
                                Order _order = new()
                                {
                                    Security = sec,
                                    Portfolio = connector.Portfolios.FirstOrDefault(p => p.Name == PortName),
                                    Side = Sides.Sell,
                                    Price = price,
                                    Volume = volume,
                                    Comment = "Manual",
                                    ClientCode = ClCode,
                                };

                                connector.RegisterOrder(_order);
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                    });
                });


            if (flag)
                await TelBot.SendMessage(81746878, "Sell request registered");
            else
                await TelBot.SendMessage(81746878, "Something went wrong!");

        }

        if (message.Text.Contains("/buybond"))
        {
            bool flag = true;
            string[] par = message.Text.Split(" ");

            if (par.Length != 4)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Security sec = connector.Securities.FirstOrDefault(s => s.Code.Contains("SU" + par.Skip(1).First()) && (s.Board == ExchangeBoard.MicexTqob));

                        if ((decimal.TryParse(par.Skip(2).First(), out decimal price)) &&
                            (decimal.TryParse(par.Skip(3).First(), out decimal volume)) && (!sec.IsNull()))
                        {
                            if (Math.Abs(OfzCurve.GetNode(sec).ModelPrice - price) > 2)
                                flag = false;
                            if ((volume <= 0) || (volume > 10000))
                                flag = false;
                            if (flag)
                            {
                                Order _order = new()
                                {
                                    Security = sec,
                                    Portfolio = connector.Portfolios.FirstOrDefault(p => p.Name == PortName),
                                    Side = Sides.Buy,
                                    Price = price,
                                    Volume = volume,
                                    Comment = "Manual",
                                    ClientCode = ClCode,
                                };

                                connector.RegisterOrder(_order);
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                    });
                });


            if (flag)
                await TelBot.SendMessage(81746878, "Buy request registered");
            else
                await TelBot.SendMessage(81746878, "Something went wrong!");

        }

        if (message.Text.Contains("/getbondinfo"))
        {
            string res = "";
            bool flag = true;

            string[] par = message.Text.Split(" ");

            if (par.Length != 2)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        string bndName = par.Skip(1).First();
                        TextBox txtBox = (TextBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "Bond_" + bndName);

                        if (txtBox.IsNull())
                            flag = false;
                        else
                        {
                            Security sec = connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + bndName)) && (s.Board == ExchangeBoard.MicexTqob));
                            res = "Bond " + bndName + ": price=" + OfzCurve.GetNode(sec).ModelPrice.ToString();

                            LongUpDown WorkVolUpD =
                               (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + bndName);
                            IntegerUpDown Offset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + bndName);
                            IntegerUpDown Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + bndName);
                            IntegerUpDown Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + bndName);
                            CheckBox IsSize = (CheckBox)LogicalTreeHelper.FindLogicalNode(MyProgram, "IsMM_" + bndName);

                            res = res + " WV=" + WorkVolUpD.Value.ToString() + " Of=" + Offset.Value.ToString() + " Ll=" +
                                          Lowlimit.Value.ToString() + " Hl=" + Highlimit.Value.ToString() + " Sz=" + IsSize.IsChecked.ToString();
                        }
                    });
                });

            if (flag)
                await TelBot.SendTextMessageAsync(message.Chat.Id, res);
            else
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Something went wrong!");
        }


        if (message.Text.Contains("/setbondprice"))
        {
            bool flag = true;

            string[] par = message.Text.Split(" ");


            if (par.Length != 3)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        decimal price;
                        var sec = connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + par.Skip(1).First())) && (s.Board == ExchangeBoard.MicexTqob));

                        if ((decimal.TryParse(par.Skip(2).First(), out price)) && (!sec.IsNull()))
                        {
                            if (Math.Abs(OfzCurve.GetNode(sec).ModelPrice - price) > 2)
                                flag = false;
                            else
                                OfzCurve.GetNode(sec).ModelPrice = price;
                        }
                        else
                        {
                            flag = false;
                        }
                    });
                });

            if (flag)
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Price changed!");
            else
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Something went wrong!");
        }

        if (message.Text.Contains("/setbondshift"))
        {
            bool flag = true;

            string[] par = message.Text.Split(" ");

            if (par.Length != 3)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Security sec = connector.Securities.FirstOrDefault(s => s.Code.Contains("SU" + par.Skip(1).First()) && (s.Board == ExchangeBoard.MicexTqob));

                        if (int.TryParse(par.Skip(2).First(), out int ofs) && (!sec.IsNull()))
                        {
                            IntegerUpDown Offset = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "Offset_" + par.Skip(1).First());

                            if ((Math.Abs(ofs) > 30) || (Offset.IsNull()))
                                flag = false;
                            else
                                Offset.Value = ofs;
                        }
                        else
                            flag = false;
                    });
                });

            if (flag)
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Shift changed!");
            else
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Something went wrong!");
        }

        if (message.Text.Contains("/setbondvolume"))
        {
            bool flag = true;

            string[] par = message.Text.Split(" ");

            if (par.Length != 3)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Security sec = connector.Securities.FirstOrDefault(s => s.Code.Contains("SU" + par.Skip(1).First()) && (s.Board == ExchangeBoard.MicexTqob));

                        if (int.TryParse(par.Skip(2).First(), out int volume) && (!sec.IsNull()))
                        {
                            LongUpDown WorkVolUpD =
                                (LongUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "WorkingVolume_" + par.Skip(1).First());

                            if ((volume < 1) || (volume > 20000) || (WorkVolUpD.IsNull()))
                                flag = false;
                            else
                            {
                                WorkVolUpD.Value = volume;
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                    });
                });

            if (flag)
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Working Volume changed!");
            else
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Something went wrong!");
        }

        if (message.Text.Contains("/setbondll"))
        {
            bool flag = true;

            string[] par = message.Text.Split(" ");

            if (par.Length != 3)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Security sec = connector.Securities.FirstOrDefault(s => s.Code.Contains("SU" + par.Skip(1).First()) && (s.Board == ExchangeBoard.MicexTqob));

                        if (int.TryParse(par.Skip(2).First(), out int llimit) && (!sec.IsNull()))
                        {
                            IntegerUpDown Lowlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "LowLimit_" + par.Skip(1).First());

                            if ((llimit < 1) || (llimit > 100) || (Lowlimit.IsNull()))
                                flag = false;
                            else
                                Lowlimit.Value = llimit;
                        }
                        else
                            flag = false;
                    });
                });

            if (flag)
                await TelBot.SendTextMessageAsync(message.Chat.Id, "LowLimit changed!");
            else
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Something went wrong!");
        }

        if (message.Text.Contains("/setbondhl"))
        {
            bool flag = true;
            string[] par = message.Text.Split(" ");

            if (par.Length != 3)
                flag = false;
            else
                await Task.Run(() =>
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Security sec = connector.Securities.FirstOrDefault(s => (s.Code.Contains("SU" + par.Skip(1).First())) && (s.Board == ExchangeBoard.MicexTqob));

                        if ((int.TryParse(par.Skip(2).First(), out int hlimit)) && (!sec.IsNull()))
                        {
                            IntegerUpDown Highlimit = (IntegerUpDown)LogicalTreeHelper.FindLogicalNode(MyProgram, "HighLimit_" + par.Skip(1).First());

                            if ((hlimit < 1) || (hlimit > 100) || (Highlimit.IsNull()))
                                flag = false;
                            else
                                Highlimit.Value = hlimit;
                        }
                        else
                            flag = false;
                    });
                });

            if (flag)
                await TelBot.SendTextMessageAsync(message.Chat.Id, "HighLimit changed!");
            else
                await TelBot.SendTextMessageAsync(message.Chat.Id, "Something went wrong!");
        }
    }
}