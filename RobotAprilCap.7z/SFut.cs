﻿using StockSharp.BusinessEntities;
using Ecng.Collections;
using System.Data;
using Ecng.Common;

namespace MyTypes;

public class SFut
{
    public decimal ModelPrice
    {
        get { return _modelPrice; }
        set { _modelPrice = value; }
    }

    public Security UnderlyingSecurity
    {
        get { return _underlyingSecurity; }
        set { _underlyingSecurity = value; }
    }

    public string Name
    {
        get { return _name; }
        set { _name = value; }
    }

    public DateTime Deliverydate
    {
        get { return _deliverydate; }
        set { _deliverydate = value; }
    }

    public decimal RepoRate
    {
        get { return _repoRate; }
        set { _repoRate = value; }
    }

    public string MicexCode
    {
        get { return _micexCode; }
        set { _micexCode = value; }
    }

    private Security _underlyingSecurity; // security from which bond is derived
    private string _name;
    private decimal _modelPrice;
    private DateTime _deliverydate;
    private decimal _repoRate;
    private string _micexCode;

    private Dictionary<SBond, decimal> ConversionFactors;

    public SFut(string name, Security sec, Dictionary<SBond, decimal> convfactors, decimal reporate, DateTime deliverydate)
    {
        _underlyingSecurity = sec;
        _micexCode = sec.Code;
        _name = name;
        _repoRate = reporate;
        _deliverydate = deliverydate;
        ConversionFactors = convfactors;
    }

    public decimal CalcFairPriceFromCurve(Curve crv)
    {
        ModelPrice = ConversionFactors.Keys.Select(s =>
        {
            //var undsec = s.UnderlyingSecurity;
            s.ModelPrice = crv.GetNode(s.UnderlyingSecurity).ModelPrice;
            return s.GetForwardPrice(s.ModelPrice / 100, RepoRate, crv.CurveDate, Deliverydate) / ConversionFactors.TryGetValue(s);

        }).Min();

        return ModelPrice;
    }
}