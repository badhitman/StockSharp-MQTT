﻿using StockSharp.BusinessEntities;

namespace MyTypes;

public class SecurityPosition
{
    public Security Sec;
    public string StrategyName;
    public decimal Offset;
    public decimal LowLimit;
    public decimal HighLimit;
    public decimal BidVolume;
    public decimal OfferVolume;
    public decimal Position;

    public SecurityPosition(Security sec, string stname, decimal lowlimit, decimal highlimit, decimal bidvolume, decimal offervolume, decimal offset)
    {
        Sec = sec;
        StrategyName = stname;
        Offset = offset;
        LowLimit = lowlimit;
        HighLimit = highlimit;
        BidVolume = bidvolume;
        OfferVolume = offervolume;
        Position = 0;
    }
}