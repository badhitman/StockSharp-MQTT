﻿using System.Net.Http;
using StockSharp.Logging;

namespace MyTypes;

/// <summary>
/// Class for Telegram application
/// </summary>
class TelegramListener : LogListener
{
    private readonly LogLevels _logLevelTelegram;
    private static string _telegramToken;
    private static string _telegramId;

    public TelegramListener(LogLevels logLevel, string telegramToken, string telegramId)
    {
        _logLevelTelegram = logLevel;
        _telegramToken = telegramToken;
        _telegramId = telegramId;
    }

    public static async void SendToTelegram(string uri)
    {
        string sendString = "https://api.telegram.org/bot" + _telegramToken + "/sendMessage?chat_id=" + _telegramId + "&text=" + uri;
        HttpClient httpClient = new();
        string content = await httpClient.GetStringAsync(sendString);
    }
}